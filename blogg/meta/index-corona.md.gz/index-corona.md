---
pagetitle: Ola Ekströms personliga blogg
---

<div id=main>

<div id=menu>[«Upp](../text.html) • [Hem](../index.html)<br>
<small>Arkiv: [2019](2019.html) • [2018](2018.html) • [2017](2017.html) •
[2016](2016.html) • [2015](2015.html)</small></div>

# Ola Ekströms personliga blogg

## 16 mars, 2020<br>Vårtecken

En farsot sprids över världen genom coronaviruset SARS-Cov-2 som är
särskilt farligt för äldre och sjuka. Katastrofstämningen hänger tung
över landet och det kommer helt klart att påverka oss alla på ett
eller annat sätt.

Men när jag cyklar till tåget på morgonen kvittrar småfåglarna som om
inget hade hänt. Världen och livet rullar på mitt i allt elände.

</div>
